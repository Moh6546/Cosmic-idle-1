Instructions de déploiement Vercel pour Cosmic Idle:

1. Crée un dépôt GitHub vide (ex: cosmic-idle)
2. Uploade tous les fichiers de ce dossier dans ton dépôt
3. Va sur https://vercel.com et connecte ton GitHub
4. Clique sur "Add New Project" et sélectionne ton dépôt
5. Laisse la détection automatique choisir "React"
6. Clique sur "Deploy"
7. Ton jeu sera disponible à une adresse comme : https://cosmic-idle.vercel.app
